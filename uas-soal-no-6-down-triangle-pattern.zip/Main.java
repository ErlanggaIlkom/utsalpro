/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Masukan Angka: ");
        
        int rows = sc.nextInt();
        for (int i=rows; i>= 1 ; i--){
            for (int j = i; j < rows ; j++){
                System.out.print(" ");
            }
            for (int k = 1; k <= (2*i -1) ;k++){
                if( k==1 || i == rows || k==(2*i-1)){
                    System.out.print("*");
                } 
                else{
                    System.out.print(" ");
                }
            }
            System.out.println("");
        }
        sc.close();
    }
}